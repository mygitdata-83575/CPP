#include<stdio.h>
int main()
{
    int n,i,a[15],j;
    printf("Enter any number: ");
    scanf("%d",&n);
    printf("Octal conversion of given no is: %o\n",n);
    printf("Hexadecimal conversion of given no is: %x\n",n);
    i=0;
    while(n>0)
    {
        a[i]=n%2;
        n=n/2;
        i++;
    }
    printf("Binary conversion of given no is: ");
    for(j=i-1;j>=0;j--)
        printf("%d",a[j]);
        
    return 0;
}

   /* int n1=n/2;//10/2=5
    int n2=n%2;//10%2=0
    int n3=n1/2;//5/2=2
    int n4=n1%2;//5%2=1
    int n5=n3/2;//2/2=0
    int n6=n3%2;//1%2=1
    int n7=n5/2;//0/2=0
    int n8=n5%2;//0%2=1 

    printf("Binary conversion of given no is:%d%d%d%d",n8,n6,n4,n2);*/
    
    
