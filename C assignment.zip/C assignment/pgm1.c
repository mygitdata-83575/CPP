#include<stdio.h>
#include<stdlib.h>

int main(int argc,char *argv[])
{
    int i;
    int max;
    for(i=1;i<=5;i++)
        if()
        
    printf("\n Result = %d",sum);
    return 0;
}