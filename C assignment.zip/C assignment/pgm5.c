#include<stdio.h>
int main()
{   
    acceptchar();
    checkchar();
    return 0;
}

void acceptchar()
{
    char ch;
    printf("Enter character: ");
    scanf("%c",&ch);
}


void checkchar()
{
    char ch;
    printf("\nEntered char no is:%d",ch);

    if(ch>65 && ch<90)
    {
        printf("\n%c is UPPERCASE Character\n",ch);
    }
    else if(ch>97 && ch<122)
    {
        printf("\n%c is LOWERCASE character\n",ch);
    }     
    else if(ch>48 && ch<57)
    {
        printf("\n%d is a NUMBER\n",ch);
    }
    else
        printf("\n%c is a Special Symbol\n",ch);        

}